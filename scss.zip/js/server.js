const nodemailer = require('nodemailer');

// Function to generate a random two-digit ID
function generateID() {
    return Math.floor(10 + Math.random() * 90); // Random number between 10 and 99
}

// Function to send email
async function sendEmail(email, uniqueID) {
    // Create a Nodemailer transporter using Gmail
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'yourgmail@gmail.com', // Your Gmail address
            pass: 'yourgmailpassword' // Your Gmail password
        }
    });

    // Send email
    let info = await transporter.sendMail({
        from: 'yourgmail@gmail.com', // Sender address
        to: email, // Receiver address
        subject: 'Your Unique ID', // Email subject
        text: `Your unique ID is: ${uniqueID}` // Email body
    });

    console.log('Email sent: ', info.messageId);
}

// Usage example
const email = 'recipient@example.com'; // Email address from the form
const uniqueID = generateID(); // Generate unique ID
sendEmail(email, uniqueID); // Send email

console.log(`Unique ID: ${uniqueID} sent to ${email}`);
